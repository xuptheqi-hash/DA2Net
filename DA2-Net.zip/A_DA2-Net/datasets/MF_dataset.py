import os, torch
from torch.utils.data.dataset import Dataset
import numpy as np
import PIL
import random
from PIL import Image
from torchvision import transforms
import torchvision.transforms.functional as TF
class MF_dataset(Dataset):

    def __init__(self, data_dir, split, input_h=480, input_w=640 ,transform=[]):
        super(MF_dataset, self).__init__()

        assert split in ['train', 'val', 'test', 'test_day', 'test_night', 'val_test', 'most_wanted'], \
            'split must be "train"|"val"|"test"|"test_day"|"test_night"|"val_test"|"most_wanted"'  # test_day, test_night

        with open(os.path.join(data_dir, split+'.txt'), 'r') as f:
            self.names = [name.strip() for name in f.readlines()]

        self.data_dir  = data_dir
        self.split     = split
        self.input_h   = input_h
        self.input_w   = input_w
        self.transform = transform
        self.n_data    = len(self.names)

    def read_image(self, name, folder):
        file_path = os.path.join(self.data_dir, '%s/%s.png' % (folder, name))
        image     = np.asarray(PIL.Image.open(file_path))
        return image

    def __getitem__(self, index):
        name  = self.names[index]
        image = self.read_image(name, 'images')
        label = self.read_image(name, 'label')
        for func in self.transform:
            image, label = func(image, label)
        image = np.asarray(PIL.Image.fromarray(image).resize((self.input_w, self.input_h)), dtype=np.float32).transpose((2,0,1))/255
        label = np.asarray(PIL.Image.fromarray(label).resize((self.input_w, self.input_h), resample=PIL.Image.NEAREST), dtype=np.int64)
        return torch.tensor(image), torch.tensor(label), name

    def __len__(self):
         return self.n_data

class train_dataset(Dataset):

    def __init__(self, data_dir, split, input_h=256, input_w=256, transform=[]):
        super(train_dataset, self).__init__()

        assert split in ['train', 'val', 'test', 'test_day', 'test_night', 'val_test', 'most_wanted'], \
            'split must be "train"|"val"|"test"|"test_day"|"test_night"|"val_test"|"most_wanted"'  # test_day, test_night

        with open(os.path.join(data_dir, split+'.txt'), 'r') as f:
            self.names = [name.strip() for name in f.readlines()]

        self.data_dir  = data_dir
        self.split     = split
        self.input_h   = input_h
        self.input_w   = input_w
        self.transform = transform
        self.transform1 = transforms.Compose([transforms.RandomHorizontalFlip(p=0.5),
                                              transforms.RandomVerticalFlip(p=0.5)])
        self.n_data    = len(self.names)


    def squ_sar(self, sar):
        return sar[:, :, 0:1].squeeze(2)
    def read_rgb_image(self, name, folder):
        file_path = os.path.join(self.data_dir, '%s\\%s.png' % (folder, name))
        image     = np.asarray(PIL.Image.open(file_path).convert("RGB"))
        return image

    def read_sar_image(self, name, folder):
        file_path = os.path.join(self.data_dir, '%s\\%s.png' % (folder, name))
        image     = np.asarray(PIL.Image.open(file_path).convert("RGB"))
        return image


    def __getitem__(self, index):
        name  = self.names[index]
        rgb = self.read_rgb_image(name, 'A')
        sar = self.read_sar_image(name, 'B')

        # sar = sar[:, :, 0:1].squeeze(2)
        # testB = self.squ_sar(testB)
        # sar = self.squ_sar(sar)
        # sar = np.expand_dims(sar, axis=2)

        label = self.read_sar_image(name, 'label')
        label = np.where(label != 0, 1, label)
        label = label[:, :, 0:1].squeeze(2)
        # label = self.squ_sar(label)

        label = modifi_label_chanel_1(label)
        for func in self.transform:
            rgb, sar, label = func(rgb, sar, label)


        rgb = np.asarray(PIL.Image.fromarray(rgb).resize((self.input_w, self.input_h)), dtype=np.float32).transpose((2,0,1))/255
        # testB = np.asarray(PIL.Image.fromarray(testB).resize((self.input_w, self.input_h)), dtype=np.float32).transpose((2,0,1))/255
        sar = np.asarray(sar, dtype=np.float32).transpose((2, 0, 1)) / 255

        label = np.asarray(PIL.Image.fromarray(label).resize((self.input_w, self.input_h), resample=PIL.Image.NEAREST), dtype=np.int64)

        # pro = random.random()
        # if pro < 0.35:
        #     image[:3, :, :] = np.zeros([3, 480, 640], dtype=np.uint8)
        # else:
        #     image = image
        rgb = torch.tensor(rgb)
        sar = torch.tensor(sar)

        label = torch.tensor(label)
        rgb = TF.normalize(rgb, mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        sar = TF.normalize(sar, mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])


        return rgb, sar, label, name

    def __len__(self):
        return self.n_data
class val_dataset(Dataset):

    def __init__(self, data_dir, split, input_h=256, input_w=256, transform=[]):
        super(val_dataset, self).__init__()

        assert split in ['train', 'val', 'test', 'test_day', 'test_night', 'val_test', 'most_wanted'], \
            'split must be "train"|"val"|"test"|"test_day"|"test_night"|"val_test"|"most_wanted"'  # test_day, test_night

        with open(os.path.join(data_dir, split + '.txt'), 'r') as f:
            self.names = [name.strip() for name in f.readlines()]

        self.data_dir = data_dir
        self.split = split
        self.input_h = input_h
        self.input_w = input_w
        self.transform = transform
        self.n_data = len(self.names)
    def squ_sar(self, sar):
        return sar[:, :, 0:1].squeeze(2)
    def read_rgb_image(self, name, folder):
        file_path = os.path.join(self.data_dir, '%s/%s' % (folder, name))
        image = np.asarray(PIL.Image.open(file_path).convert("RGB"))
        return image

    def read_sar_image(self, name, folder):
        file_path = os.path.join(self.data_dir, '%s/%s' % (folder, name))
        image = np.asarray(PIL.Image.open(file_path).convert("RGB"))
        return image

    def __getitem__(self, index):
        name = self.names[index]
        rgb = self.read_rgb_image(name, 'A')
        sar = self.read_sar_image(name, 'B')
        # testB = self.squ_sar(testB)
        # sar = self.squ_sar(sar)
        # sar = np.expand_dims(sar, axis=2)
        label = self.read_sar_image(name, 'label')
        label = np.where(label != 0, 1, label)
        label = label[:, :, 0:1].squeeze(2)
        # label = self.squ_sar(label)
        label = modifi_label_chanel_1(label)
        # for func in self.transform:
        #     testA, testB, label = func(testA, testB, label)
        rgb = np.asarray(PIL.Image.fromarray(rgb), dtype=np.float32).transpose(
            (2, 0, 1)) / 255
        # testB = np.asarray(PIL.Image.fromarray(testB).resize((self.input_w, self.input_h)), dtype=np.float32).transpose((2,0,1))/255
        sar = np.asarray(sar, dtype=np.float32).transpose((2, 0, 1)) / 255
        label = np.asarray(PIL.Image.fromarray(label),
                           dtype=np.int64)

        rgb = torch.tensor(rgb)
        sar = torch.tensor(sar)
        label = torch.tensor(label)
        rgb = TF.normalize(rgb, mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        sar = TF.normalize(sar, mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])

        return rgb, sar, label, name

    def __len__(self):
        return self.n_data
def modifi_label_chanel_1(a):

    pixel_mapping = {
            0: 0,
            255: 1,
    }
    label_copy = np.copy(a)
    for i, j in pixel_mapping.items():
        label_copy[label_copy == i] = j
    return label_copy

if __name__ == '__main__':
    from torch.utils.data import DataLoader
    test_dataset = train_dataset(data_dir='D:\\PyCharm\\Project\\A_yan1xia\\SFAF\\dataset3\\train', split='train', input_h=256,
                              input_w=256, )
    test_loader = DataLoader(
        dataset=test_dataset,
        batch_size=4,
        shuffle=False,
        num_workers=0,
        pin_memory=True,
        drop_last=False
    )
    for data in enumerate(test_loader):
        a = data
        rgb = a[1][0]
        sar = a[1][1]
        label = a[1][2]
        name = a[1][3]
        break